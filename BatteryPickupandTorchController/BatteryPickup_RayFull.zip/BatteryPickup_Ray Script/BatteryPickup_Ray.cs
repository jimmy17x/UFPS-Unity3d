﻿using UnityEngine;
using System.Collections;

public class BatteryPickup_Ray : MonoBehaviour {

	public GameObject battery , pistol;

	private Light torch; // light source of pistol game object

	private bool  guiShow = false; 

	private int rayLength = 10; // colliding distance with a battery

	void  Start (){
		torch = pistol.GetComponent<Light>(); 
	}
	
	void  OnGUI (){
		if(guiShow)
		{
			GUI.Box( new Rect(Screen.width / 2, Screen.height / 2, 100, 25 ), "Pick up batteries!");
		}
	}
	
	void  Update (){

		Debug.Log(guiShow);
		RaycastHit hit;

		Vector3 fwd= transform.TransformDirection (Vector3.forward);


		//on collision 
		if (Physics.Raycast (transform.position, fwd, out hit, rayLength)) 
		{
			// pick up battery
			if(hit.collider.gameObject == battery )
			{
				guiShow = true; // gui

				if(Input.GetKeyDown(KeyCode.E))
				{
					torch.intensity += 0.5f;
					Debug.Log("Intensity" + torch.intensity);
					guiShow = false;
					Destroy(battery);// remove picked battery from scene

				}
			}
		}
		
		else
		{
			guiShow = false;
		} // ends on collision
	}
}