Directions

1.)Add a 3D Cube GameObject as a battery with Halo Effect
2.)Drag BatteryPickup_Ray.cs to FPSCamera 
3.)Add variables for battery , light and weapon ( weapon with Light source )
4.)Initialize light variable with Light component of weapon in script BatteryPickup_Ray.cs
5.)Drag and drop Light source  (of weapon )as a value for weapon variable in Inspector 
6.)Drag and drop battery GameObject as a value for Battery variable in Inspector
