
using UnityEngine;
using System.Collections;

public class TorchController : MonoBehaviour {

	public AudioClip torchClick;
	public GameObject pistol;

	private Light torch; //  light source of pistol
	void  Start (){

		torch = pistol.GetComponent<Light>();
		torch.enabled = false;
		torch.intensity = 8;
	}


	
	void  Update (){
		if(torch.enabled == true)
		{
			torch.intensity -= 0.1f * Time.deltaTime / 5;
			Debug.Log(torch.intensity);
		}
		
		if(Input.GetKeyDown(KeyCode.F))
		{
			GetComponent<AudioSource>().PlayOneShot(torchClick);

			torch.enabled = !torch.enabled;

		}

		if (torch.enabled && Input.GetKeyDown (KeyCode.Q)) {

			torch.intensity += 0.05f;
			GetComponent<AudioSource>().PlayOneShot(torchClick);
		}

	}
}