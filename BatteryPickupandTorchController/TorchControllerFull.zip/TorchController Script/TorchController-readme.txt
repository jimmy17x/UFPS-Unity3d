Directions

1.)Add Light source to weapon on UFPS prefab
2.)Drag TorchController.cs to FPSCamera
3.)Add variables for  weapon and click sound
4.)Drag and drop Light source as a value for weapon variable in Inspector
