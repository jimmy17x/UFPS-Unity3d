Directions:

1.) Create two empty game objects acting as placeholders for spawning enemy
2.) Water.cs is a component for Waterbox gameobject , add variables for enemy object, Transform spawnpoints array and spawn time .
3.) Create a function Spawn() which is invoked in OnTriggerStay() .
4.) Spawn enemy inside Spawn() and add acceleration force  in direction of waterobject , which triggered collision. 
