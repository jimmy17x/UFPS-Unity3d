Directions 
1.)Along with main GuiSurvival.cs main script ,  create a Water.cs ,Food.cs and Fire.cs script
2.)Drag and Drop GuiSurvival.cs to WeaponCamera as a component
3.)Similarly drag other scripts to Water , Food and Fire GameObject
4.)Add variables for Texture icons and survival ranges for body temperature ,hunger ,thirst and health
5.)Drag and drop icons asset from directory SurvivalIcons to value fields in Inspector for GuiSurvival.cs of WeaponCamera
6.)Check isTrigger on Water, Fire and Food GameObject
7.)Create variables for WeaponCamera and respective GameObject in survival GameObjects
8.)Assign WeaponCamera and GameObject to fields in inspector