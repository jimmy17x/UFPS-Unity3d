using UnityEngine;
using System.Collections;

public class Tags : MonoBehaviour
{
	// A list of tag strings.
	public const string MACHINE_GUN_BULLET_TAG = "MachineGunBulletTag";
	public const string PISTOL_BULLET_TAG = "PistolBulletTag";
	public const string REVOLVER_BULLET_TAG = "RevolverBulletTag";
	public const string FIREBOX_TAG = "FireBoxTag";

}