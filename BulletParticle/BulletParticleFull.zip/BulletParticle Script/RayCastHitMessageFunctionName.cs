using UnityEngine;
using System.Collections;

public class RayCastHitMessageFunctionName : MonoBehaviour
{
	// A list of damage function names in different objects to be used to spawn bullet particles 
	public const string PISTOL_HIT = "pistol_damage";
	
}