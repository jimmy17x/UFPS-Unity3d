1)Stude ThermalController.cs file ,  its commented wherevr required
2)Refer screenshot of inspector for dragging and dropping Frost and Heat Icons
3)Spawning only turns-on disabled object - usng raycast the boolean variables "isConsumingHeat" and "isNearToFirePlace" controlls heat consuming logic 
4)Adjust constant variables to test for suitable values for heat , frost temp and damage rate